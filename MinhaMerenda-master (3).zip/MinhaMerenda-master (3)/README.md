# MinhaMerenda
<br>
<p><b>Kotlin/Java code in:</b><a href="https://github.com/marcosbarbosa031/MinhaMerenda/tree/master/app/src/main/java/com/tac/marcos/minhamerenda"> app/src/main/java/com/tac/marcos/minhamerenda/</a></p>
<br>
<div><img src="https://i.imgur.com/ZEcTBk3.png" width="auto" height="80%">
<span style="margin-left: 20px;"><img src="https://i.imgur.com/gaSZAbi.png" width="auto" height="80%"></span>
</div>
